// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"

#include <vector> // Added for vector operations
#include <stdexcept> // Added for out_of_range exception

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// Verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // Verify initial state
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  // Verify collection is not empty and has one element
  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 1);
}

// Verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);

  // Verify collection has five elements
  EXPECT_EQ(collection->size(), 5);
  EXPECT_FALSE(collection->empty());
}

// Verify max_size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsAtLeastSize)
{
  // Test for 0 entries
  EXPECT_GE(collection->max_size(), collection->size());

  // Test for 1 entry
  add_entries(1);
  EXPECT_GE(collection->max_size(), collection->size());

  // Test for 5 entries
  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->max_size(), collection->size());

  // Test for 10 entries
  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->max_size(), collection->size());
}

// Verify capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsAtLeastSize)
{
  // Test for 0 entries
  EXPECT_GE(collection->capacity(), collection->size());

  // Test for 1 entry
  add_entries(1);
  EXPECT_GE(collection->capacity(), collection->size());

  // Test for 5 entries
  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->capacity(), collection->size());

  // Test for 10 entries
  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->capacity(), collection->size());
}

// Verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  // Resize to 10 elements
  collection->resize(10);

  // Verify size is 10
  EXPECT_EQ(collection->size(), 10);
  // Verify new elements are initialized to 0
  for (const auto& val : *collection) {
    EXPECT_EQ(val, 0);
  }
}

// Verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  // Add 10 elements
  add_entries(10);
  auto old_capacity = collection->capacity();

  // Resize to 5 elements
  collection->resize(5);

  // Verify size is 5, capacity unchanged
  EXPECT_EQ(collection->size(), 5);
  EXPECT_EQ(collection->capacity(), old_capacity);
}

// Verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
  // Add 5 elements
  add_entries(5);

  // Resize to 0
  collection->resize(0);

  // Verify collection is empty
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
  // Add 5 elements
  add_entries(5);

  // Clear collection
  collection->clear();

  // Verify collection is empty
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRangeClearsCollection)
{
  // Add 5 elements
  add_entries(5);

  // Erase all elements
  collection->erase(collection->begin(), collection->end());

  // Verify collection is empty
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Verify reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
  // Add 5 elements
  add_entries(5);
  auto old_size = collection->size();
  auto old_capacity = collection->capacity();

  // Reserve more space
  collection->reserve(20);

  // Verify size unchanged, capacity increased
  EXPECT_EQ(collection->size(), old_size);
  EXPECT_GE(collection->capacity(), 20);
}

// Verify std::out_of_range exception is thrown for at() with invalid index (Negative Test)
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
  // Add 5 elements
  add_entries(5);

  // Expect out_of_range exception for index >= size
  ASSERT_THROW(collection->at(collection->size()), std::out_of_range);
}

// Custom Positive Test: Verify push_back adds element to end
TEST_F(CollectionTest, PushBackAddsToEnd)
{
  // Add one element
  collection->push_back(42);

  // Verify size and last element
  EXPECT_EQ(collection->size(), 1);
  EXPECT_EQ(collection->back(), 42);
}

// Custom Negative Test: Verify pop_back on empty collection throws exception
TEST_F(CollectionTest, PopBackOnEmptyThrows)
{
  // Expect exception when calling pop_back on empty collection
  ASSERT_THROW(collection->pop_back(), std::out_of_range);
}